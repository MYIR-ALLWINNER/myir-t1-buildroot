/* automatically generated. DO NOT EDIT. */
#define GITHASH "ae9450cc5e56d3ef6763ca4a0fc507b908073b4c"
#define GITDIFF ""
