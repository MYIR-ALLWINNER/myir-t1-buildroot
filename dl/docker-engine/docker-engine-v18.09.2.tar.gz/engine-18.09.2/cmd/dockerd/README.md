docker.go contains Docker daemon's main function.

This file provides first line CLI argument parsing and environment variable setting.
